﻿public class AspNetUserRegister
{
    public string Email;
    public string Password;
    public string ConfirmPassword;
}
